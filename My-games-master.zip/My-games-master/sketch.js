
 
var player,playeridle;
var bg;
var playerWalk;
var playerAttack;
var demonWalk,demonAttack,demonDeath,demonIdle;
var dragonAttack,dragonDeath,dragonWalk,dragonIdle,dragonFireAttack;
var jinnAttack,jinnDeath,jinnIdle,jinnMagicAttack,jinnWalk;
var medusaAttack,medusaDeath,medusaIdle,medusaStone,medusaWalk;
var lizardAttack,lizardDeath,lizardIdle,lizardWalk;

var demon,dragon,medusa,jinn,lizard;

var bg2;


function preload(){
playeridle=loadAnimation("idle.png");
playerWalk=loadAnimation("1.png","2.png","3.png","4.png","5.png");
playerAttack= loadAnimation("attack1.png","attack2.png","attack3.png","attack4.png");
playerJump= loadAnimation("jump2.png","jump3.png","jump4.png","jump5.png","jump6.png");

demonWalk= loadAnimation("demonWalk1.png","demonWalk2.png","demonWalk3.png","demonWalk4.png","demonWalk5.png","demonWalk6.png");
demonAttack= loadAnimation("demonAttack1.png","demonAttack2.png","demonAttack3.png","demonAttack4.png")
demonDeath= loadAnimation("Death1.png","Death2.png","Death3.png","Death4.png","Death5.png");
demonIdle=loadAnimation("idle1.png");

dragonWalk=loadAnimation("Walk1.png","Walk2.png","Walk3.png","Walk4.png","Walk5.png");
dragonDeath=loadAnimation("Death1 (2).png","Death2 (2).png","Death3 (2).png","Death4 (2).png","Death5 (2).png");
dragonAttack=loadAnimation("dragonAttack1.png","Attack2 (2).png","Attack3 (2).png","Attack4 (2).png");
dragonFireAttack=loadAnimation("Fire_Attack1.png","Fire_Attack2.png","Fire_Attack3.png","Fire_Attack4.png","Fire_Attack5.png");
dragonIdle=loadAnimation("idle2.png");

jinnWalk=loadAnimation("Flight1.png","Flight2.png","Flight3.png","Flight4.png");
jinnAttack=loadAnimation("Attack1 (5).png","Attack2 (5).png","Attack3 (5).png","Attack4 (5).png");
jinnMagicAttack=loadAnimation("Magic_Attack1.png","Magic_Attack2.png","Magic_Attack3.png","Magic_Attack4.png","Magic_Attack5.png","Magic_Attack6.png","Magic_Attack7.png","Magic_Attack8.png","Magic_Attack9.png","Magic_Attack10.png","Magic_Attack11.png","Magic_Attack22.png","Magic_Attack23.png");
jinnDeath=loadAnimation("Death1 (5).png","Death2 (5).png","Death3 (5).png","Death4 (5).png","Death5 (4).png","Death6.png");
jinnIdle=loadAnimation("idle3.png");

lizardWalk=loadAnimation("Walk1 (3).png","Walk2 (3).png","Walk3 (3).png","Walk4 (4).png","Walk5 (2).png","Walk6.png");
lizardAttack=loadAnimation("Attack1 (4).png","Attack2 (4).png","Attack3 (4).png","Attack4 (3).png","Attack5.png");
lizardDeath=loadAnimation("Death1 (4).png","Death2 (4).png","Death3 (4).png","Death4 (3).png","Death5 (3).png");
lizardIdle=loadAnimation("idle1 (3).png");

medusaAttack=loadAnimation("Attack1 (6).png","Attack2 (6).png","Attack3 (6).png","Attack4 (5).png","Attack5 (2).png","Attack6.png");
medusaWalk=loadAnimation("Walk1 (4).png","Walk2 (4).png","Walk3 (4).png","Walk4 (4).png");
medusaDeath=loadAnimation("Death1 (6).png","Death2 (6).png","Death3 (6).png","Death4 (5).png","Death5 (5).png");
medusaStone=loadAnimation("Stone1.png","Stone2.png","Stone3.png","Stone4.png","Stone5.png","Stone6.png","Stone7.png");
medusaIdle=loadAnimation("idle2 (2).png");

bg= loadImage("BG.png");
bg2= loadImage("background.jpg");


}




function setup() {
  canvas=createCanvas(displayWidth-30,800);
  spike=createImg("spike.gif")

  player = createSprite(100,600);
  player.addAnimation("idle",playeridle);
  player.addAnimation("walk",playerWalk);
  player.addAnimation("attack",playerAttack);
  player.addAnimation("jump",playerJump);
   player.scale=0.3;

   demon.addAnimation("walk",demonWalk);
   demon.addAnimation("attack1",demonAttack);
   demon.addAnimation("idle1",demonIdle);
   demon.addAnimation("death1",demonDeath);
    demon.scale = 0.6;
   
    dragon.addAnimation("walk2",dragonWalk);
    dragon.addAnimation("attack2",dragonAttack);
    dragon.addAnimation("fire attack2",dragonFireAttack);
    dragon.addAnimation("death2",dragonDeath);
    dragon.addAnimation("idle2",dragonIdle);
     dragon.scale = 0.7;

     jinn.addAnimation("flight",jinnWalk);
     jinn.addAnimation("attack3",jinnAttack);
     jinn.addAnimation("magic attack",jinnMagicAttack);
     jinn.addAnimation("death3",jinnDeath);
     jinn.addAnimation("idle3",jinnIdle);
      jinn.scale = 0.4;

     medusa.addAnimation("walk4",medusaWalk);
     medusa.addAnimation("attack4",medusaAttack);
     medusa.addAnimation("death4",medusaDeath);
     medusa.addAnimation("stone",medusaStone);
     medusa.addAnimation("idle",medusaIdle);
      medusa.scale = 0.3;

     lizard.addAnimation("walk5",lizardWalk);
     lizard.addAnimation("attack5",lizardAttack);
     lizard.addAnimation("death5",lizardDeath);
     lizard.addAnimation("idle5",lizardIdle);
      lizard.scale= 0.2;
    background(bg);
}
    

 



function draw() {
  background(bg);

  if (player.x>displayWidth-30){
    
    bg= loadImage("background.jpg");

    player.x=50;
    player.y=800-50;

    demon.x= 50;
    demon.y=755;

    spike.position(400,700);

    

  }

  demon.velocityX=(-2,0);


   if(keyWentDown(RIGHT_ARROW)){
    player.velocityX= 2;
    player.changeAnimation("walk");
   } 

   if(keyWentUp(RIGHT_ARROW)){
    player.velocityX= 0;
    player.changeAnimation("idle");
   } 

   if(keyWentDown(LEFT_ARROW)){
    player.velocityX= -2;
    player.changeAnimation("walk");
   } 

   if(keyWentUp(LEFT_ARROW)){
    player.velocityX= 0;
    player.changeAnimation("idle");
   } 

   if(keyWentDown(UP_ARROW)){
    player.velocityX= 2;
    player.velocityY= -3;
    player.changeAnimation("jump");
   } 

   if(keyWentUp(UP_ARROW)){
   player.velocityX= 0;
    player.velocityY= 0;
    player.changeAnimation("idle");
   } 

   if(keyWentDown("space")){
    
    player.changeAnimation("attack");
   } 

   if(keyWentUp("space")){
    
    player.changeAnimation("idle");
   } 
 drawSprites();

}
